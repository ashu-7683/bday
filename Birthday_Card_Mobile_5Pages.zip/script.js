
function showPage(pageNum) {
  const totalPages = 5;
  for (let i = 1; i <= totalPages; i++) {
    const page = document.getElementById(`page${i}`);
    if (page) {
      page.classList.add("hidden");
    }
  }
  const newPage = document.getElementById(`page${pageNum}`);
  if (newPage) {
    newPage.classList.remove("hidden");
  }
  document.getElementById("bg-music").play();
}
